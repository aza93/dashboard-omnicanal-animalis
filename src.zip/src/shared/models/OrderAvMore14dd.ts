export class OrderAvMore14dd {
    magasin: string;
    date_creation: string;
    date_mise_de_cote: string;
    dispo_depuis: number;
    type_commande: string;
    numero_commande: number;
    nom_client: string;
    tel: string;
    nb_produits: number;
}
