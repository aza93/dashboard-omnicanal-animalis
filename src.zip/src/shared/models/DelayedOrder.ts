export class DelayedOrder {
    magasin: string;
    date_creation: string;
    type_commande: string;
    numero_commande: number;
    nom_client: string;
    tel: string;
    nb_produits: number;
    retard: number;
}
