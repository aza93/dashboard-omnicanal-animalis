export class OrderShipping {
    magasin: string;
    date_commande: string;
    date_expedition: string;
    type_commande: string;
    numero_commande: number;
    nom_client: string;
    tel: string;
    nb_produits: number;
}
