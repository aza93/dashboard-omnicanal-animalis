export class OrderInProgress {
    magasin: string;
    date_commande: string;
    type_commande: string;
    numero_commande: number;
    nom_client: string;
    tel: string;
    nb_produits: number;
}
