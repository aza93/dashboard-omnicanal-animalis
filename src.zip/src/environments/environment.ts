// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiUrlMagento: 'http://abdellah-n6foo5a-o4lvm5zl7t3ym.fr-1.platformsh.site',
  apiUrlMagento1: 'https://staging-m2.animalis.com',
  apiUrlMagento2: 'http://staging-m2.animalis.com.c.o4lvm5zl7t3ym.dev.ent.platform.sh/'
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
